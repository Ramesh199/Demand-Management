from django.db import models
from datetime import datetime
from dateutil.relativedelta import relativedelta
from django.utils.timezone import now
import numpy as np
import datetime as dt


class Demand_Master(models.Model):
	
	STATUS =(
	    ('Open', 'Open'),
	    ('In-Progress', 'In-Progress'),
	    ('Hold', 'Hold'),
	    ('Cancelled', 'Cancelled'),
	    ('Closed', 'Closed')
	)


	PORTFOLIO = (
	        ('Clinical Decision Support', 'Clinical Decision Support'),
	        ('Clinical Survelliance', 'Clinical Survelliance'),
	        ('Contigo Health', 'Contigo Health'),
	        ('Corp IT', 'Corp IT'),
	        ('Cost Management', 'Cost Management'),
	        ('Development Operations', 'Development Operations'),
	        ('GPO', 'GPO'),
	        ('Infrastructure', 'Infrastructure'),
	        ('Innovatix', 'Innovatix'),
	        ('IPA', 'IPA'),
	        ('Population Health', 'Population Health'),
	        ('PAS', 'PAS'),
	        ('Quality & Population Health', 'Quality & Population Health')
	)


	PLEAD = (
	        ('Alex Tatiyants', 'Alex Tatiyants'),
	        ('Chris Ickert', 'Chris Ickert'),
	        ('Denise Juliano', 'Denise Juliano'),
	        ('Greg Montano', 'Greg Montano'),
	        ('Pawan Singh', 'Pawan Singh'),
	        ('Saima Khan', 'Saima Khan'),
	        ('Saji Rajasekharan', 'Saji Rajasekharan'),
	        ('Todd Wilkes', 'Todd Wilkes')
	)

	LOCATION = (
        ('Off', 'Off'),
        ('On', 'On'),
        ('On-Off', 'On-Off')
    )

	RFLAG = (
	        ('Yes', 'Yes'),
	        ('No', 'No'),
	        ('N/A', 'N/A')
	)

	DSTATUS = (
        ('0 - GAVS Sourcing/Screening', '0 - GAVS Sourcing/Screening'),
        ('1 - Premier Reviewing Profiles', '1 - Premier Reviewing Profiles'),
        ('2 - Premier Interviewing', '2 - Premier Interviewing'),
        ('3 - Candidate Selected', '3 - Candidate Selected'),
        ('4 - GAVS Onboarding in Progress', '4 - GAVS Onboarding in Progress'),
        ('5 - Premier Onboarding in Progress', '5 - Premier Onboarding in Progress'),
        ('6 - Candidate Started', '6 - Candidate Started'),
        ('7 - On Hold', '7 - On Hold'),
        ('8 - Cancelled', '8 - Cancelled')
    )


	Fiscal_Year = models.CharField(max_length=4, default='BLANK')
	Requested_Date = models.DateField(default=datetime.now)
	#Days_Open = models.IntegerField(default=0)
	Demand_Status = models.CharField(max_length=25, choices = STATUS, default='BLANK')
	Demand_Id = models.CharField(max_length=10, default='BLANK')
	Portfolio = models.CharField(max_length=100, choices = PORTFOLIO, default='BLANK')
	Portfolio_Lead = models.CharField(max_length=50, choices = PLEAD, default='BLANK')
	Hiring_Manager = models.CharField(max_length=50, default='BLANK')
	Project = models.CharField(max_length=100, default='BLANK')
	Role = models.CharField(max_length=100, default='BLANK')
	Skillset = models.CharField(max_length=100, default='BLANK')
	Location = models.CharField(max_length=10, choices = LOCATION, default='BLANK')
	Onshore_Replacement_Flag = models.CharField(max_length=3, choices = RFLAG, default='N/A')
	Planned_Start_Date = models.DateField(default=datetime.now)
	Expected_Start_Date = models.DateField(default=datetime.now)
	Detailed_Status = models.CharField(max_length=50, choices = DSTATUS, default='BLANK')
	Notes = models.TextField(default='BLANK')
	Candidate = models.CharField(max_length=100, default='BLANK')
	Client_Feedback = models.CharField(max_length=200, default='BLANK')
	Log_Date = models.DateField(default=datetime.now(), null=True)

	def __str__(self):
		return self.Demand_Id


	def get_year(self):
	    return self.Requested_Date.year