from django.apps import AppConfig


class Demand_ManagerConfig(AppConfig):
    name = 'Demand_Manager'
