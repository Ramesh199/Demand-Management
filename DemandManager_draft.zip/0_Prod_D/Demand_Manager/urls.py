from django.urls import path
from . import views

app_name = 'Demand_Manager'

urlpatterns = [
    path('', views.home, name="home"),
    path("<str:pk>/update_detail/", views.updateDetail, name="update_detail"),
    path("table_detail/", views.tableDetail, name="table_detail"),   
    
]