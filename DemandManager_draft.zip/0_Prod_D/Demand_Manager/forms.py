from django.forms import ModelForm
from .models import Demand_Master
from django import forms


class DateInput(forms.DateInput):
	input_type= 'date'

class CalendarUtilForm(forms.Form):
	Expected_Start_Date = forms.DateField(widget=DateInput)

class UpdateForm(ModelForm):
	Demand_Id = forms.CharField(label='Demand Id',
				widget=forms.TextInput(attrs={"readonly":"readonly"}))
	class Meta:
		model= Demand_Master
		
		fields = ['Fiscal_Year', 
				'Demand_Status', 
				'Demand_Id', 
				'Portfolio', 
				'Portfolio_Lead',
				'Hiring_Manager',
				'Project',
				'Role',
				'Skillset',
				'Location',
				'Onshore_Replacement_Flag',
				'Expected_Start_Date',
				'Detailed_Status',
				'Notes'
				]
			
		widgets = {'Expected_Start_Date':DateInput()}