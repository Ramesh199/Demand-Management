from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Demand_Master
from django.db.models import Count
from datetime import date, timedelta, datetime
from django.contrib import messages
from .forms import UpdateForm



def home(request):
	
	now = datetime.now().date()
	earlier = now - timedelta(days=7)
	now = now.strftime('%Y-%m-%d')
	earlier = earlier.strftime('%Y-%m-%d')
	date_format = "%Y-%m-%d"
	sysdate = datetime.strptime(str(datetime.now().date()), date_format)

	context = {"Open_Demands_Dict":Demand_Master.objects.exclude(Demand_Status = "Closed").exclude(Demand_Status = "Cancel").order_by('-Demand_Status'),
	"Demand_Count_dict":Demand_Master.objects.exclude(Demand_Status = "Closed").exclude(Demand_Status = "Cancel").exclude(Demand_Status = "Hold").values('Demand_Status', 'Location').annotate(total=Count('id')).order_by('Demand_Status', 'Location'),
	"Demand_DS_Count_dict":Demand_Master.objects.values('Detailed_Status').annotate(total=Count('id')).order_by('Detailed_Status'),
	"Demand_Wk_Interviewed_dict": Demand_Master.objects.filter(Log_Date__gte = earlier, Detailed_Status = '2 - Premier Interviewing'),
	"Demand_Wk_Selected_dict": Demand_Master.objects.filter(Log_Date__gte = earlier, Detailed_Status = '3 - Candidate Selected'),
	"Demand_Wk_Started_dict": Demand_Master.objects.filter(Log_Date__gte = earlier, Detailed_Status = '6 - Candidate Started')
	}

	return render(request, 'Demand_Manager/dashboard.html', context)

def tableDetail(request):
	
	return render(request,
				  "Demand_Manager/table9.html",
				  context = {"Demand_Dashboard":Demand_Master.objects.all}
				  )

def addDetail(request):

	return render(request, "Demand_Manager/add_Detail.html")

def updateDetail(request, pk):
	
	detail = Demand_Master.objects.get(id=pk)
	form = UpdateForm(instance=detail)
	if request.method == 'POST':
		form = (UpdateForm(request.POST, instance=detail))
		if form.is_valid():
			messages.info(request, f"Demand details updated successfully")
			form.save()
			
			return redirect("Demand_Manager:home")
			

	context = {'form':form}
	return render(request, "Demand_Manager/update_Detail.html", context)